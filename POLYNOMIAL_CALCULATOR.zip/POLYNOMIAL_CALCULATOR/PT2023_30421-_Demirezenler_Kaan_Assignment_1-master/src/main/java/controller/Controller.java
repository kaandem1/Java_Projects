package controller;

import models.Parser;
import models.Polynomial;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {
    private JTextField poly1;
    private JTextField poly2;
    private JTextField resultField;

    public Controller(JTextField poly1, JTextField poly2, JTextField resultField) {
        this.poly1 = poly1;
        this.poly2 = poly2;
        this.resultField = resultField;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();


            switch (button.getText()) {
                case "ADD":
                    Polynomial p1 = Parser.parse(poly1.getText());
                    Polynomial p2 = Parser.parse(poly2.getText());
                    Polynomial result = null;
                    result = p1.add(p2);
                    if (result != null) {
                        resultField.setText(result.toString());
                    }
                    break;
                case "SUBTRACT":
                    Polynomial sp1 = Parser.parse(poly1.getText());
                    Polynomial sp2 = Parser.parse(poly2.getText());
                    Polynomial sresult = null;
                    sresult = sp1.subtract(sp2);
                    if (sresult != null) {
                        resultField.setText(sresult.toString());
                    }
                    break;
                case "MULTIPLY":
                    Polynomial mp1 = Parser.parse(poly1.getText());
                    Polynomial mp2 = Parser.parse(poly2.getText());
                    Polynomial mresult = null;
                    mresult = mp1.multiply(mp2);
                    if (mresult != null) {
                        resultField.setText(mresult.toString());
                    }
                    break;
                case "DERIVATE":
                    Polynomial dep1 = Parser.parse(poly1.getText());
                    Polynomial dresult = null;
                    dresult = dep1.derivate();
                    if (dresult != null) {
                        resultField.setText(dresult.toString());
                    }
                    break;
                case "INTEGRATE":
                    Polynomial ip1 = Parser.parse(poly1.getText());
                    Polynomial iresult = null;
                    iresult = ip1.integrate();
                    if (iresult != null) {
                        resultField.setText(iresult.toString());
                    }

                    break;
                case "DIVIDE":
                    Polynomial dip1 = Parser.parse(poly1.getText());
                    Polynomial dip2 = Parser.parse(poly2.getText());
                    Polynomial diresult = null;
                    try{
                        diresult= dip1.divide(dip2);
                    }catch(ArithmeticException ex){
                        JOptionPane.showMessageDialog(null, "Division by zero", "Error", JOptionPane.ERROR_MESSAGE);
                    }catch (Exception ex){

                    }
                    if (diresult != null) {
                        resultField.setText(diresult.toString());
                    }

                    break;
                case "CLEAR":
                    poly1.setText("");
                    poly2.setText("");
                    resultField.setText("");
                    break;
            }

        }
    }
}
