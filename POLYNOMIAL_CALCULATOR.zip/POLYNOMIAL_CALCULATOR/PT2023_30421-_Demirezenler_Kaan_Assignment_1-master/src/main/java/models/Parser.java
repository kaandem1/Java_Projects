package models;

import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class Parser {
    public static Polynomial parse(String input) {
        Polynomial result = new Polynomial();
        //split the input string into individual terms
        String[] terms = input.split("(?=[+-])");
        //iterate over each term and extract its coefficient and power
        for (String term : terms) {
            double sign = 1;
            double coefficient = 0;
            double power = 0;
            //check if the term neg or pos
            if (term.startsWith("-")) {
                sign = -1;
                term = term.substring(1);
            } else if (term.startsWith("+")) {
                term = term.substring(1);
            }
            //check if the term matches +)?", matches a polynomial term with an optional sign, optional decimal digits before and after “x”, and an optional exponent with an optional sign and decimal digits
            if (term.matches("[+-]?\\d*\\.?\\d*x(\\^(\\+|-)?\\d*\\.?\\d+)?")) {
                //extract the power from the term, or set it to 1 if no power is specified
                if (term.indexOf("^") >= 0) {
                    power = Double.parseDouble(term.substring(term.indexOf("^") + 1));
                } else {
                    power = 1;
                }
                //extract the coefficient from the term, or set it to 1 if no coefficient is specified
                String coefficientString = term.substring(0, term.indexOf("x"));
                if (coefficientString.equals("") || coefficientString.equals("+") || coefficientString.equals("-")) {
                    coefficient = sign;
                } else {
                    coefficient = Double.parseDouble(coefficientString) * sign;
                }
                //check if the term matches constant term
            } else if (term.matches("[+-]?\\d*\\.?\\d+(?!x)")) {
                coefficient = Double.parseDouble(term) * sign;
                power = 0;
                //check if the term matches only a power and no coefficient
            } else if (term.matches("[+-]?x\\^(\\+|-)?\\d*\\.?\\d+")) {
                power = Double.parseDouble(term.substring(term.indexOf("^") + 1));
                coefficient = sign;
                //else display an error message and return null
            } else {
                JOptionPane.showMessageDialog(null, "Invalid polynomial form: " + term + ". Please enter a valid polynomial.", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }

            //add the term's coefficient to the corresponding power in the result poly
            double currentCoefficient = result.getCoefficient(power);
            result.setCoefficient(power, currentCoefficient + coefficient);
        }

        return result;
    }
}
