package models;

import java.util.*;
import javax.swing.JOptionPane;
public class Polynomial {
    public Map<Double, Double> coefficients;

    public Polynomial() {
        coefficients = new HashMap<>();
    }


    public void setCoefficient(double degree, double coefficient) {
        coefficients.put(degree, coefficient);
    }

    public double getCoefficient(double degree) {
        return coefficients.getOrDefault(degree, 0.0);
    }

    public double getDegree() {
        // returns the highest degree of the polynomial by iterating through the degrees in the coefficients map
        double maxDegree = 0;
        for (double degree : coefficients.keySet()) {
            if (degree > maxDegree) {
                maxDegree = degree;
            }
        }
        return maxDegree;
    }

    public Polynomial add(Polynomial other) {
        Polynomial result = new Polynomial();
        //iterate through the degrees of this and other
        for (double degree : this.coefficients.keySet()) {
            double sum = this.getCoefficient(degree) + other.getCoefficient(degree);
            //add tbe coeffs of each deg
            result.setCoefficient(degree, sum);
            //and set the coeffs in "result"
        }
        for (double degree : other.coefficients.keySet()) {
            if (!this.coefficients.containsKey(degree)) {
                //if other contains a degree non existent in p1, add it to the result
                double sum = this.getCoefficient(degree) + other.getCoefficient(degree);
                result.setCoefficient(degree, sum);
            }
        }

        return result;
    }

    public Polynomial subtract(Polynomial other) {
        Polynomial result = new Polynomial();
        for (double degree : this.coefficients.keySet()) {
            //for each term
            double diff = this.getCoefficient(degree) - other.getCoefficient(degree);
            //subtract the corresponding terms
            result.setCoefficient(degree, diff);
        }
        for (double degree : other.coefficients.keySet()) {
            //if other contains a term that doesnt exist
            if (!this.coefficients.containsKey(degree)) {
                double diff = -other.getCoefficient(degree);
                // add it as a negative term to the result
                result.setCoefficient(degree, diff);
            }
        }

        return result;
    }

    public Polynomial multiply(Polynomial other) {
        Polynomial result = new Polynomial();
        for (double degree1 : this.coefficients.keySet()) {
            // loop through all the degrees of the first polynomial
            for (double degree2 : other.coefficients.keySet()) {
                //do the same for the second p
                double product = this.getCoefficient(degree1) * other.getCoefficient(degree2);
                //multiply the coefficients at each degree
                double degree = degree1 + degree2;
                //add the degrees together to get the degree of the product
                double currentCoefficient = result.getCoefficient(degree);
                //add the product to the current coefficient of that degree
                result.setCoefficient(degree, currentCoefficient + product);
            }
        }
        return result;
    }

    public Polynomial derivate() {
        Polynomial result = new Polynomial();
        for (double degree : coefficients.keySet()) {
            //go through each degree
            double coefficient = coefficients.get(degree);
            //for each, retrieve the coeff
            if (degree > 0) {
                //if degree greater than 0
                result.setCoefficient(degree - 1, degree * coefficient);
                //derivate
            }
        }
        return result;
    }
    public Polynomial integrate() {
        Polynomial result = new Polynomial();

        // check if p1 has constant term
        boolean hasConstantTerm = false;
        for (double degree : this.coefficients.keySet()) {
            if (degree == 0) {
                hasConstantTerm = true;
                result.setCoefficient(1, this.getCoefficient(degree));
            } else {
                //integrate each non-constant term by adding 1 to the degree and dividing the coefficient by the new degree
                double newDegree = degree + 1;
                double newCoefficient = this.getCoefficient(degree) / newDegree;
                result.setCoefficient(newDegree, newCoefficient);
            }
        }
        //if the original Polynomial didn't have a constant term, add one to the result Polynomial with a coefficient of 0
        if (!hasConstantTerm) {
            result.setCoefficient(0, 0);
        }
        return result;
    }

    public Polynomial divide(Polynomial divisor) throws ArithmeticException {
        //check if divisor is zero polynomial
        if (divisor.coefficients.isEmpty() || (divisor.coefficients.size() == 1 && divisor.coefficients.containsKey(0.0) && divisor.coefficients.get(0.0) == 0.0)) {
            throw new ArithmeticException("Division by zero polynomial");
        }
        // initialize quotient and remainder
        Polynomial quotient = new Polynomial();
        Polynomial remainder = new Polynomial();
        remainder.coefficients.putAll(this.coefficients);
        //perform polynomial long division
        for (double i = remainder.getDegree(); i >= divisor.getDegree(); i--) {
            // calculate the quotient coefficient
            double quotientCoefficient = remainder.getCoefficient(i) / divisor.getCoefficient(divisor.getDegree());
            //set the coefficient of the quotient polynomial
            quotient.setCoefficient(i - divisor.getDegree(), quotientCoefficient);

            //calculate the product of the divisor and quotient term
            Polynomial product = new Polynomial();
            product.setCoefficient(i - divisor.getDegree(), quotientCoefficient);
            Polynomial temp = divisor.multiply(product);
            //update the remainder
            remainder = remainder.subtract(temp);
        }
        return quotient;
    }



    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        boolean isFirstTerm = true;
        boolean hasTerms = false;
        //sort degrees in descending order
        List<Double> degrees = new ArrayList<>(coefficients.keySet());
        Collections.sort(degrees, Collections.reverseOrder());
        for (double degree : degrees) {
            double coefficient = coefficients.get(degree);
            if (coefficient != 0) {
                hasTerms = true;
                if (isFirstTerm) {
                    // handle first term
                    if (coefficient < 0) {
                        sb.append("-");
                    }
                    isFirstTerm = false;
                } else {
                    // handle other terms
                    if (coefficient > 0) {
                        sb.append(" + ");
                    } else {
                        sb.append(" - ");
                        coefficient = -coefficient;
                    }
                }
                //append coefficient if != 1 or if degree = 0
                if (coefficient != 1 || degree == 0) {
                    sb.append(String.format("%.3f", Math.abs(coefficient)));
                }
                //append variable with degree if degree >0
                if (degree > 0) {
                    sb.append("x");
                    if (degree % 1 != 0) {
                        //append fractional exponent if degree != int
                        sb.append("^").append(String.format("%.3f", degree));
                    } else if (degree > 1) {
                        //ppend integer exponent if degree > 1
                        sb.append("^").append((int) degree);
                    }
                }
            }
        }
        //if no terms, append "0"
        if (!hasTerms) {
            sb.append("0");
        }
        return sb.toString();
    }



}