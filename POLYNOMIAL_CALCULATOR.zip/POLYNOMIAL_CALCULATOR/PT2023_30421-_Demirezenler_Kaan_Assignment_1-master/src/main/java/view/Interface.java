package view;

import controller.Controller;
import models.Polynomial;
import models.Parser;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Interface extends JFrame {
    private JPanel panel;
    private JPanel paneel1;
    private JButton addButton;
    private JTextField poly1;
    private JTextField poly2;
    private JTextField resultField;
    private JButton SUBTRACTButton;
    private JButton MULTIPLYButton;
    private JButton DERIVATEButton;
    private JButton CLEARButton;
    private JButton INTEGRATEButton;
    private JButton DIVIDEbutton;

    public Interface() {
        add(panel);

        Controller controller = new Controller(poly1, poly2, resultField);

        addButton.addActionListener(controller);
        SUBTRACTButton.addActionListener(controller);
        MULTIPLYButton.addActionListener(controller);
        DERIVATEButton.addActionListener(controller);
        CLEARButton.addActionListener(controller);
        INTEGRATEButton.addActionListener(controller);
        DIVIDEbutton.addActionListener(controller);
    }
}
