package view;

import view.Interface;

public class Main {
    public static void main(String[] args) {
        Interface userInput = new Interface();
        userInput.setSize(800, 400);
        userInput.setVisible(true);
    }
}