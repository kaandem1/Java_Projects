package test;

import models.Parser;
import models.Polynomial;
import org.testng.Assert;
import org.testng.annotations.Test;

class PolynomialTest {
    @Test
    static void add(){
        Polynomial p1 = Parser.parse("2x+1");
        Polynomial p2 = Parser.parse("x");
        Polynomial expResult = Parser.parse("3x+1");
        Assert.assertEquals(expResult.toString(),p1.add(p2).toString());
        System.out.println("Test for Addition:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 2: "+p2);
        System.out.println("Polynomial 1 + Polynomial 2 :"+ p1.add(p2).toString()+"\n");


    }
    static void sub(){
        Polynomial p1 = Parser.parse("2x+1");
        Polynomial p2 = Parser.parse("x");
        Polynomial expResult = Parser.parse("x+1");

        Assert.assertEquals(expResult.toString(),p1.subtract(p2).toString());
        System.out.println("Test for Subtraction:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 2: "+p2);
        System.out.println("Polynomial 1 - Polynomial 2 :"+ p1.subtract(p2).toString()+"\n");

    }
    static void mult(){
        Polynomial p1 = Parser.parse("2x+1");
        Polynomial p2 = Parser.parse("x");
        Polynomial expResult = Parser.parse("2x^2+x");

        Assert.assertEquals(expResult.toString(),p1.multiply(p2).toString());
        System.out.println("Test for Multiplication:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 2: "+p2);
        System.out.println("Polynomial 1 * Polynomial 2 :"+ p1.multiply(p2).toString()+"\n");

    }

    static void deriv(){
        Polynomial p1 = Parser.parse("2x+1");
        Polynomial expResult = Parser.parse("2");

        Assert.assertEquals(expResult.toString(),p1.derivate().toString());
        System.out.println("Test for Derivation:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 1 derivated:"+ p1.derivate().toString()+"\n");

    }

    static void integr(){
        Polynomial p1 = Parser.parse("x");
        Polynomial expResult = Parser.parse("0.500x^2");

        Assert.assertEquals(expResult.toString(),p1.integrate().toString());
        System.out.println("Test for Integration:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 1 integrated :"+ p1.integrate().toString()+"\n");

    }

    static void div(){
        Polynomial p1 = Parser.parse("x");
        Polynomial p2 = Parser.parse("2x");
        Polynomial expResult = Parser.parse("0.500");

        Assert.assertEquals(expResult.toString(),p1.divide(p2).toString());
        System.out.println("Test for Division:");
        System.out.println("Polynomial 1: "+p1);
        System.out.println("Polynomial 2: "+p2);
        System.out.println("Polynomial 1 / Polynomial 2 :"+ p1.divide(p2).toString()+"\n");


    }

    public static void main(String[] args){
        add();
        sub();
        mult();
        deriv();
        integr();
        div();
    }
}


