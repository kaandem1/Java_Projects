package model;

import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable{

    private BlockingQueue<Task> tasks;


    private AtomicInteger waitingPeriod;
    private int qID;

    public Server() {
        tasks = new LinkedBlockingQueue<Task>();
        waitingPeriod = new AtomicInteger(0);

    }

    public int getqID() {
        return qID;
    }

    public void setqID(int qID) {
        this.qID = qID;
    }

    public AtomicInteger getWaitingPeriod() {
        return waitingPeriod;
    }

    public void setWaitingPeriod(AtomicInteger waitingPeriod) {
        this.waitingPeriod = waitingPeriod;
    }

    public void setTasks(BlockingQueue<Task> tasks) {
        this.tasks = tasks;
    }


    public BlockingQueue<Task> getTasks() {
        return tasks;
    }


    public void addTask(Task newTask) {
        tasks.add(newTask);
        waitingPeriod.addAndGet(newTask.getServiceTime());
    }

    public void run() {
        boolean flag = true;
        while(flag){
            try{
                Task nextTask = tasks.take();
                Thread.sleep(nextTask.getServiceTime()*1000L);
                waitingPeriod.decrementAndGet();
                if(waitingPeriod.get()==0){
                    flag=false;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }



//    public void run() {
//        while (true) {
//            try {
//                if(tasks.size()>0){
//                    // Take the next task from the queue
//                    Task nextTask = tasks.peek();
//                   // assert nextTask != null;
//                    int tService =nextTask.getServiceTime();
//                    while(tService>0){
//                        Thread.sleep(1000L);
//                        waitingPeriod.addAndGet(-1000);
//                        nextTask.setServiceTime(--tService);
//                        System.out.println("a");
//                    }
//                    tasks.remove(nextTask);
//
//                }
//
//            } catch (InterruptedException e) {
//                // Handle interrupted exception
//                e.printStackTrace();
//            }
//        }
//    }



    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Queue "+qID+":");
        for(Task task:getTasks()){

           sb.append(task.toString());
        }

        return sb.toString();
    }
}