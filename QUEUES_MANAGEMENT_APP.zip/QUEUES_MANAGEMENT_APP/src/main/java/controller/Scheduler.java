package controller;

import model.Server;
import model.Task;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Scheduler {
    private List<Server> servers;
    private int maxNoServers;
    private int maxTasksPerServer;
   // private ConcreteStrategyTime concreteStrategyTime;
    private Strategy strategy;

    public Scheduler(int maxNoServers, int maxTasksPerServer) {
        this.servers = new ArrayList<>();

        // Create maxNoServers servers and threads
        for (int i = 0; i < maxNoServers; i++) {
            BlockingQueue<Task> tasks = new ArrayBlockingQueue<>(maxTasksPerServer);
            AtomicInteger waitingPeriod = new AtomicInteger();
            Server server = new Server();
            server.setTasks(tasks);
            server.setWaitingPeriod(waitingPeriod);
            servers.add(server);
        }
    }

    public void changeStrategy(SelectionPolicy policy) {
        if (policy == SelectionPolicy.SHORTEST_TIME) {
            strategy = new ConcreteStrategyTime();
        }
        if (policy == SelectionPolicy.SHORTEST_QUEUE) {
            strategy = new ConcreteStrategyQueue();
        }
    }

//    public int[] getSizes(){
//        int[] queues = new int[servers.size()];
//        for(int i=0;i<servers.size();i++){
//            BlockingQueue<Task> queue = servers.get(i).getTasks();
//            queues[i] = queue.size();
//        }
//        return queues;
//    }


    public void dispatchTask(Task task) {
        // Call the strategy addTask method
        strategy.addTask(servers, task);

    }

    public List<Server> getServers() {
        return servers;
    }
}

interface Strategy {
    void addTask(List<Server> servers, Task task);
}

class ConcreteStrategyTime implements Strategy {
   // public Server shortestServer;
    @Override
    public void addTask(List<Server> servers, Task task) {
        int shortestWaitingPeriod = Integer.MAX_VALUE;
        Server shortestTimeServer = servers.get(0);
        //System.out.println("nr of servers: "+servers.size());
        for (Server server : servers) {

            int waitingPeriod = server.getWaitingPeriod().get();
            //System.out.println(shortestQueueServer.getqID()+" "+ "Waiting Period: "+waitingPeriod);

            if (waitingPeriod < shortestWaitingPeriod) {
                shortestWaitingPeriod = waitingPeriod;
                shortestTimeServer = server;

            }

        }
        shortestTimeServer.addTask(task);
        //shortestServer=shortestTimeServer;
    }

//    public Server getMinTask(){
//        return shortestServer;
//    }
}



class ConcreteStrategyQueue implements Strategy {
    public void addTask(List<Server> servers, Task task) {
        Server shortestQueueServer = servers.get(0);
        for (Server server : servers) {
            if (server.getTasks().size() < shortestQueueServer.getTasks().size()) {
                shortestQueueServer = server;
            }
        }
        shortestQueueServer.addTask(task);
    }
}

