package controller;

public enum SelectionPolicy {
    SHORTEST_TIME, SHORTEST_QUEUE
}