package controller;

import model.Server;
import model.Task;
import view.SimulationFrame;
import controller.ConcreteStrategyTime;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.*;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class SimulationManager implements Runnable {
    //data read from UI
    public int timeLimit ;//maximum processing time - read from UI
    public int maxServiceTime ;
    public int minServiceTime ;
    public int numberOfServers;
    public int numberOfClients;
    public int maxArrivalTime;
    public int minArrivalTime;


    public SelectionPolicy selectionPolicy = SelectionPolicy.SHORTEST_TIME;

    //entity responsible with queue management and client distribution
    private Scheduler scheduler;

    //private ConcreteStrategyTime concreteStrategyTime;
    //frame for displaying simulation
    private SimulationFrame frame;
    //pool of tasks (client shopping in the store)
    private List<Task> generatedTasks;

    public SimulationManager(SimulationFrame frame) {
        this.frame = frame;
        this.frame.addStartListener(new StartListener());
        //initialize selection strategy
        //generate numberOfClients clients using generateNRandomTasks()
        //initialize frame to display simulation

    }

    public List<Task> generateNRandomTasks(int numberOfClients){

        generatedTasks = new ArrayList<>();
        //n, min max arrival, min max serv
        minArrivalTime = frame.getMinIntervalArrival();
        maxArrivalTime = frame.getTextMaxT();
        minServiceTime = frame.getMinServTime();
        maxServiceTime = frame.getMaxServTime();

        if (minServiceTime > maxServiceTime || minArrivalTime > maxArrivalTime) {
            throw new IllegalArgumentException("Invalid input: minimum value cannot be greater than maximum value.");
        }else{
            //minServiceTime < serviceTime < maxServiceTime
            //random arrivalTime
            //generate N random tasks;
            //-random service time

            for(int i =1 ; i <= numberOfClients; i++){
                int randArrival = (int) (Math.random() * (maxArrivalTime - minArrivalTime + 1)) + minArrivalTime;
                int randService = (int) (Math.random() * (maxServiceTime - minServiceTime + 1)) + minServiceTime;
                generatedTasks.add(new Task(i,randArrival,randService));

            }
            try {
                PrintStream fileOut = new PrintStream("output.txt");
                System.setOut(fileOut);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

        }
        //sort list with respect to arrivalTime
        Collections.sort(generatedTasks, new Comparator<Task>() {
            public int compare(Task t1, Task t2) {
                return t1.getArrivalTime() - t2.getArrivalTime();
            }
        });
        for (Task generatedTask : generatedTasks) {
            System.out.println(generatedTask);
        }
        return generatedTasks;
    }

    class StartListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            // Check if any text fields are left empty
            try {
                    numberOfServers = frame.getTextQ();
                    numberOfClients = frame.getTextClients();
                    int maxCperQ = numberOfClients/numberOfServers;
                // sim start code here
                scheduler = new Scheduler(numberOfServers, maxCperQ);
                for (int i = 0; i < numberOfServers; i++) {
                    Thread thread = new Thread(scheduler.getServers().get(i));
                    thread.start();
                }
                Thread thread1 = new Thread(SimulationManager.this);
                thread1.start();
            }catch (Exception exception){
                JOptionPane.showMessageDialog(null,"Error","Error",JOptionPane.ERROR_MESSAGE);
                exception.printStackTrace();
            }
        }
    }
//    public int getAvgWait(){
//        int avgWait=0;
//        for(int i =0;i<generatedTasks.size();i++){
//            generatedTasks.
//        }
//            return avgWait;
//    }


    public void run() {
        int currentTime = 0;
        //int servTime=0;

        numberOfClients = frame.getTextClients();
        numberOfServers = frame.getTextQ();
        minArrivalTime = frame.getMinIntervalArrival();
        timeLimit = frame.getTextSimT();
        maxArrivalTime = frame.getTextMaxT();
        minServiceTime = frame.getMinServTime();
        maxServiceTime = frame.getMaxServTime();
        scheduler = new Scheduler(numberOfServers,100);
        scheduler.changeStrategy(selectionPolicy);
        generatedTasks= generateNRandomTasks(numberOfClients);

        try {
            PrintStream fileOut = new PrintStream(new FileOutputStream("output.txt", true));
            System.setOut(fileOut);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        List<Server> servers = scheduler.getServers();
        int mostTasks=0;
        int peak=0;
        int TotalWait=0;
        int TotalServ = 0;

        while (currentTime < timeLimit) {
            for(Iterator<Task> iterator = generatedTasks.iterator();iterator.hasNext();){
                Task task = iterator.next();
                if(task.getArrivalTime() == currentTime){
                    scheduler.dispatchTask(task);
                    TotalServ += task.getServiceTime();
                    iterator.remove();

                }
            }
//            int[] queues = scheduler.getSizes();
//
//            if(mostTasks<Arrays.stream(queues).sum()){
//                mostTasks = Arrays.stream(queues).sum();
//                peak = currentTime;
//
//            }
            System.out.println("Current time:"+currentTime);
            for(int i =0; i<servers.size();i++){
                Server server = servers.get(i);
                Task firstTask = server.getTasks().peek();

                System.out.print("Queue " + (i + 1) + ": ");
                BlockingQueue<Task> tasks = server.getTasks();
                boolean tN1Done = false;
                for(Iterator<Task> iterator = tasks.iterator();iterator.hasNext();){
                    Task task = iterator.next();
                    System.out.println(task.toString());

                    if(task.getID()==firstTask.getID()&&!tN1Done){
                        task.decrementServTime();
                        tN1Done=true;
                    }

                    if(task.getServiceTime()==0){
                        iterator.remove();
                    }
                }
                System.out.println();
            }
            currentTime++;
        }
        //System.out.println("a");
    }

    public static class Main {
        public static void main(String[] args) {
            SimulationFrame frame1 = new SimulationFrame();
            frame1.setVisible(true);
            frame1.setSize(400,400);
            SimulationManager gen = new SimulationManager(frame1);


        }
    }



}
