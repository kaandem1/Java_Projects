package connection;

import com.mysql.cj.jdbc.MysqlDataSource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The ConnectionFactory class is responsible for creating and managing database connections.
 */
public class ConnectionFactory {
    private static final Logger LOGGER = Logger.getLogger(ConnectionFactory.class.getName());
    private static final String servername = "localhost";
    private static final String dbname = "order_management";
    private static final String username = "root";
    private static final Integer portnumber = 3307;
    private static final String password = ""; // no password

    private ConnectionFactory() {
    }

    /**
     * Retrieves a connection to the database.
     *
     * @return The database connection.
     */
    public static Connection getTheConnection() {
        Connection connection = null;
        try {
            MysqlDataSource datasource = new MysqlDataSource();
            datasource.setServerName(servername);
            datasource.setUser(username);
            datasource.setDatabaseName(dbname);
            datasource.setPortNumber(portnumber);
            datasource.setPassword(password);
            connection = datasource.getConnection();
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }

    /**
     * Closes the result set.
     *
     * @param rs The result set to be closed.
     */
    public static void close(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    /**
     * Closes the statement.
     *
     * @param stmt The statement to be closed.
     */
    public static void close(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }

    /**
     * Closes the database connection.
     *
     * @param conn The database connection to be closed.
     */
    public static void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                Logger.getLogger(ConnectionFactory.class.getName()).log(Level.SEVERE, null, e);
            }
        }
    }
}