package presentation;

import model.Client;
import utils.TableUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * The ManageClientPage class represents a GUI window for managing clients.
 * It extends the JFrame class.
 */
public class ManageClientPage extends JFrame {
    private JPanel panel;
    private JTable clientsTable;
    private JButton loadClientsButton;
    private JButton addClientButton;
    private JButton editClientButton;
    private JButton deleteClientButton;

    /**
     * Constructs an instance of ManageClientPage.
     * Sets the size and layout of the window.
     * Initializes the components.
     */
    public ManageClientPage() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        panel = new JPanel();
        clientsTable = new JTable();
        loadClientsButton = new JButton("Load Clients");
        addClientButton = new JButton("Add Client");
        editClientButton = new JButton("Edit Client");
        deleteClientButton = new JButton("Delete Client");

        this.add(addClientButton, BorderLayout.NORTH);
        this.add(editClientButton, BorderLayout.EAST);

        this.add(deleteClientButton, BorderLayout.WEST);
        this.add(panel, BorderLayout.CENTER);
        this.add(loadClientsButton, BorderLayout.SOUTH);
        JScrollPane scrollPane = new JScrollPane(clientsTable);
        panel.add(scrollPane);




    }

    /**
     * Sets the action listener for the loadClientsButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setLoadClientsButtonActionListener(ActionListener actionListener) {
        loadClientsButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the addClientButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setAddClientButtonActionListener(ActionListener actionListener) {
        addClientButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the editClientButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setEditClientButtonActionListener(ActionListener actionListener) {
        editClientButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the deleteClientButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setDeleteClientButtonActionListener(ActionListener actionListener) {
        deleteClientButton.addActionListener(actionListener);
    }

    /**
     * Loads the provided list of clients into the clientsTable.
     *
     * @param clients the list of clients to be loaded
     */
    public void loadClients(List<Client> clients) {
        TableUtil.populateTable(clientsTable, clients);
    }
}