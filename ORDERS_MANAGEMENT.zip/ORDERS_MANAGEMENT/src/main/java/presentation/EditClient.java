package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The EditClient class represents a JFrame for editing a client.
 */
public class EditClient extends JFrame {
    private JLabel idLabel;
    private JTextField idField;
    private JButton confirmButton;

    /**
     * Constructs a new EditClient object.
     */
    public EditClient() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        idLabel = new JLabel("Enter Client ID:");
        idField = new JTextField();
        confirmButton = new JButton("Confirm");

        this.add(idLabel, BorderLayout.NORTH);
        this.add(idField, BorderLayout.CENTER);
        this.add(confirmButton, BorderLayout.SOUTH);
    }

    /**
     * Sets the action listener for the confirm button.
     *
     * @param actionListener The action listener to be set.
     */
    public void setConfirmButtonActionListener(ActionListener actionListener) {
        confirmButton.addActionListener(actionListener);
    }

    /**
     * Retrieves the client ID entered in the text field.
     *
     * @return The client ID.
     */
    public int getClientId() {
        return Integer.parseInt(idField.getText());
    }
}
