package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The EditProduct class provides a graphical user interface for editing a product.
 * It extends JFrame, meaning it can be instantiated as a window with components like labels, text fields and buttons.
 */
public class EditProduct extends JFrame {

    private JLabel idLabel;
    private JTextField idField;
    private JButton confirmButton;

    /**
     * Constructs an EditProduct window with specific size, layout and components including a label, a text field and a button.
     */
    public EditProduct() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        idLabel = new JLabel("Enter Product ID:");
        idField = new JTextField();
        confirmButton = new JButton("Confirm");

        this.add(idLabel, BorderLayout.NORTH);
        this.add(idField, BorderLayout.CENTER);
        this.add(confirmButton, BorderLayout.SOUTH);
    }

    /**
     * Adds an ActionListener to the confirm button.
     * When the confirm button is clicked, the ActionListener is invoked.
     *
     * @param actionListener The ActionListener to be added.
     */
    public void setConfirmButtonActionListener(ActionListener actionListener) {
        confirmButton.addActionListener(actionListener);
    }


    /**
     * Retrieves the product ID entered by the user.
     *
     * @return The product ID as an integer.
     */

    public int getClientId() {
        return Integer.parseInt(idField.getText());
    }
}