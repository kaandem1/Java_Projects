package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.event.ActionListener;

/**
 * The AdminView class represents the main JFrame for the admin interface.
 */
public class AdminView extends JFrame {
    private JPanel panel;
    private JButton manageClientsButton;
    private JButton manageProductsButton;
    private JLabel title;

    /**
     * Constructs a new AdminView object.
     */
    public AdminView() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());
        panel = new JPanel();
        title = new JLabel("Please select.");
        manageClientsButton = new JButton("Manage Clients");
        manageProductsButton = new JButton("Manage Products");

        this.add(manageClientsButton, BorderLayout.WEST);
        this.add(manageProductsButton, BorderLayout.EAST);

        this.add(panel, BorderLayout.CENTER);

    }

    /**
     * Adds an ActionListener to the "Manage Clients" button.
     *
     * @param action The ActionListener to be added.
     */
    public void addManageClientsButton(ActionListener action) {
        manageClientsButton.addActionListener(action);
    }

    /**
     * Adds an ActionListener to the "Manage Products" button.
     *
     * @param action The ActionListener to be added.
     */
    public void addManageProductsButton(ActionListener action) {
        manageProductsButton.addActionListener(action);
    }
}
