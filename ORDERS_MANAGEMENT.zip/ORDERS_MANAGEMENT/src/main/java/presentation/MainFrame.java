package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private JPanel panel;
    private JLabel title;
    private JButton useAsClientButton;
    private JButton useAsAdminButton;

    public MainFrame() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());
        panel = new JPanel();
        title = new JLabel("Please select.");
        useAsClientButton = new JButton("Use as Client");
        useAsAdminButton = new JButton("Use as Admin");

        this.add(useAsClientButton, BorderLayout.NORTH);
        this.add(useAsAdminButton, BorderLayout.EAST);

        this.add(panel, BorderLayout.CENTER);

    }

    public void addUseAsAdminButton(ActionListener action){
        useAsAdminButton.addActionListener(action);
    }

    public void addUseAsClientButton(ActionListener action){ // New method
        useAsClientButton.addActionListener(action);
    }

}
