package presentation;

import model.Client;

import javax.swing.*;
import java.awt.*;

/**
 * The DeleteClient class represents a JFrame for deleting a client.
 */
public class DeleteClient extends JFrame {
    private JLabel clientIdLabel;
    private JLabel nameLabel;
    private JLabel addressLabel;
    private JLabel emailLabel;
    private JLabel phoneLabel;
    private JButton confirmDeleteButton;
    private JButton cancelButton;
    private int clientId;

    /**
     * Constructs a new DeleteClient object.
     *
     * @param client The client to be deleted.
     */
    public DeleteClient(Client client) {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        clientId = client.getId();

        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        clientIdLabel = new JLabel("ID: " + client.getId());
        formPanel.add(clientIdLabel);

        nameLabel = new JLabel("Name: " + client.getName());
        formPanel.add(nameLabel);

        addressLabel = new JLabel("Address: " + client.getAddress());
        formPanel.add(addressLabel);

        emailLabel = new JLabel("E-mail: " + client.getEmail());
        formPanel.add(emailLabel);

        phoneLabel = new JLabel("Phone: " + client.getPhoneNumber());
        formPanel.add(phoneLabel);

        this.add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        confirmDeleteButton = new JButton("Confirm Delete");
        cancelButton = new JButton("Cancel");
        buttonPanel.add(confirmDeleteButton);
        buttonPanel.add(cancelButton);

        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the confirm delete button.
     *
     * @return The confirm delete button.
     */
    public JButton getConfirmDeleteButton() {
        return confirmDeleteButton;
    }

    /**
     * Retrieves the cancel button.
     *
     * @return The cancel button.
     */
    public JButton getCancelButton() {
        return cancelButton;
    }

    /**
     * Retrieves the client ID.
     *
     * @return The client ID.
     */
    public int getClientId() {
        return clientId;
    }
}
