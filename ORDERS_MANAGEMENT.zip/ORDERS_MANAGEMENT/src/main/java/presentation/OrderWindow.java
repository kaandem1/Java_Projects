package presentation;

import model.Client;
import model.Product;
import utils.TableUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.util.List;

/**
 * The OrderWindow class represents the user interface for the Order Window in the Order Management system.
 */
public class OrderWindow extends JFrame {
    private JPanel panel;
    private JLabel welcomeLabel;
    private JTable productsTable;
    private JButton loadProductsButton;
    private JButton orderButton;
    private JLabel productLabel;
    private JTextField quantityField;
    private Client client;

    /**
     * Constructs a new OrderWindow object with a given client.
     *
     * @param client the client who is placing an order.
     */
    public OrderWindow(Client client) {
        this.client = client;

        this.setSize(500, 500);
        this.setLayout(new BorderLayout());

        welcomeLabel = new JLabel("Welcome " + client.getName() + ". What would you like to order?");
        productsTable = new JTable();
        loadProductsButton = new JButton("Load Products");
        orderButton = new JButton("Order");
        productLabel = new JLabel("");
        quantityField = new JTextField(5);

        panel = new JPanel();
        panel.add(loadProductsButton);
        panel.add(orderButton);
        panel.add(productLabel);
        panel.add(quantityField);

        this.add(welcomeLabel, BorderLayout.NORTH);
        this.add(new JScrollPane(productsTable), BorderLayout.CENTER);
        this.add(panel, BorderLayout.SOUTH);
    }

    /**
     * Adds an action listener to the load products button.
     *
     * @param actionListener the action listener.
     */
    public void setLoadProductsButtonListener(ActionListener actionListener) {
        loadProductsButton.addActionListener(actionListener);
    }

    /**
     * Adds an action listener to the order button.
     *
     * @param listener the action listener.
     */
    public void setOrderButtonActionListener(ActionListener listener) {
        orderButton.addActionListener(listener);
    }

    /**
     * Adds a mouse click listener to the products table.
     *
     * @param mouseAdapter the mouse click listener.
     */
    public void setProductsTableClickListener(MouseAdapter mouseAdapter) {
        productsTable.addMouseListener(mouseAdapter);
    }

    /**
     * Retrieves the client of the current OrderWindow.
     *
     * @return the client.
     */
    public Client getClient() {
        return client;
    }

    /**
     * Retrieves the quantity entered in the text field.
     *
     * @return the quantity.
     */
    public int getQuantity(){
        return Integer.parseInt(quantityField.getText());
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public JTable getProductsTable() {
        return productsTable;
    }

    public void setProductsTable(JTable productsTable) {
        this.productsTable = productsTable;
    }

    public JButton getLoadProductsButton() {
        return loadProductsButton;
    }

    public void setLoadProductsButton(JButton loadProductsButton) {
        this.loadProductsButton = loadProductsButton;
    }

    public JButton getOrderButton() {
        return orderButton;
    }

    public void setOrderButton(JButton orderButton) {
        this.orderButton = orderButton;
    }

    public JLabel getProductLabel() {
        return productLabel;
    }

    public void setProductLabel(JLabel productLabel) {
        this.productLabel = productLabel;
    }

    public JTextField getQuantityField() {
        return quantityField;
    }

    public void setQuantityField(JTextField quantityField) {
        this.quantityField = quantityField;
    }

    /**
     * Retrieves the ID of the selected product in the products table.
     *
     * @return the selected product ID.
     * @throws IllegalStateException if no product is selected.
     */
    public int getSelectedProductId() {
        int selectedRow = productsTable.getSelectedRow();
        if (selectedRow != -1) {  // If a row is selected
            int selectedProductId = (Integer) productsTable.getValueAt(selectedRow, 0);
            return selectedProductId;
        } else {
            // throw an exception or return some indicator of failure
            throw new IllegalStateException("No product selected");
        }
    }

    /**
     * Populates the products table with a list of products.
     *
     * @param products the list of products.
     */
    public void loadProducts(List<Product> products) {
        TableUtil.populateTable(productsTable, products);
    }



}
