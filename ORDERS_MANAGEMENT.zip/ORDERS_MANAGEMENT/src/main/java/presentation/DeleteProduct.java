package presentation;

import model.Client;
import model.Product;

import javax.swing.*;
import java.awt.*;

/**
 * The DeleteProduct class represents a JFrame for deleting a product.
 */
public class DeleteProduct extends JFrame {
    private JLabel productIdLabel;
    private JLabel nameLabel;
    private JLabel descLabel;
    private JLabel priceLabel;
    private JLabel stockLabel;
    private JButton confirmDeleteButton;
    private JButton cancelButton;
    private int productId;

    /**
     * Constructs a new DeleteProduct object.
     *
     * @param product The product to be deleted.
     */
    public DeleteProduct(Product product) {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        productId = product.getId();

        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        productIdLabel = new JLabel("ID: " + product.getId());
        formPanel.add(productIdLabel);

        nameLabel = new JLabel("Name: " + product.getName());
        formPanel.add(nameLabel);

        descLabel = new JLabel("Description: " + product.getDescription());
        formPanel.add(descLabel);

        priceLabel = new JLabel("Price: " + product.getPrice());
        formPanel.add(priceLabel);

        stockLabel = new JLabel("Stock: " + product.getStock());
        formPanel.add(stockLabel);

        this.add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
        confirmDeleteButton = new JButton("Confirm Delete");
        cancelButton = new JButton("Cancel");
        buttonPanel.add(confirmDeleteButton);
        buttonPanel.add(cancelButton);

        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the confirm delete button.
     *
     * @return The confirm delete button.
     */
    public JButton getConfirmDeleteButton() {
        return confirmDeleteButton;
    }

    /**
     * Retrieves the cancel button.
     *
     * @return The cancel button.
     */
    public JButton getCancelButton() {
        return cancelButton;
    }

    /**
     * Retrieves the product ID.
     *
     * @return The product ID.
     */
    public int getProductId() {
        return productId;
    }
}
