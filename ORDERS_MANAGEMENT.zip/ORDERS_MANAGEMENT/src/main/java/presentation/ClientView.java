package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * The ClientView class represents a JFrame for the client interface.
 */
public class ClientView extends JFrame {
    private JPanel panel;
    private JLabel instructionLabel;
    private JTextField emailField;
    private JButton confirmButton;

    /**
     * Constructs a new ClientView object.
     */
    public ClientView() {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        instructionLabel = new JLabel("Please input your email address:");
        emailField = new JTextField();
        confirmButton = new JButton("Confirm");

        this.add(instructionLabel, BorderLayout.NORTH);
        this.add(emailField, BorderLayout.CENTER);
        this.add(confirmButton, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the email address entered in the text field.
     *
     * @return The email address.
     */
    public String getEmail() {
        return emailField.getText();
    }

    /**
     * Sets an ActionListener for the confirm button.
     *
     * @param actionListener The ActionListener to be set.
     */
    public void setConfirmButtonActionListener(ActionListener actionListener) {
        confirmButton.addActionListener(actionListener);
    }
}

