package presentation;

import model.Client;
import model.Product;

import javax.swing.*;
import java.awt.*;

/**
 * The UpdateProduct class represents a GUI window for updating product information.
 * It extends the JFrame class.
 */
public class UpdateProduct extends JFrame{
    private JTextField nameField;
    private JTextField descField;
    private JTextField priceField;
    private JTextField stockField;
    private JLabel titleLabel;

    private JButton updateButton;
    private int productId;

    /**
     * Constructs an instance of UpdateProduct.
     * Initializes the size, layout, and components of the window.
     *
     * @param product the product to be updated
     */
    public UpdateProduct(Product product) {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        productId = product.getId();

        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        titleLabel = new JLabel("Updating: " + product.getName() + "'s information");
        this.add(titleLabel, BorderLayout.NORTH);

        formPanel.add(new JLabel("Name:"));
        nameField = new JTextField(product.getName());
        formPanel.add(nameField);

        formPanel.add(new JLabel("Description:"));
        descField = new JTextField(product.getDescription());
        formPanel.add(descField);

        formPanel.add(new JLabel("Price:"));
        priceField = new JTextField(String.valueOf(product.getPrice()));
        formPanel.add(priceField);

        formPanel.add(new JLabel("Stock:"));
        stockField = new JTextField(product.getStock());
        formPanel.add(stockField);

        this.add(formPanel, BorderLayout.CENTER);

        updateButton = new JButton("Update");
        this.add(updateButton, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the updateButton.
     *
     * @return the JButton for updating product information
     */
    public JButton getUpdateButton() {
        return updateButton;
    }

    /**
     * Retrieves the product name entered in the nameField.
     *
     * @return the product name as a String
     */
    public String getProductName() {
        return nameField.getText();
    }

    /**
     * Retrieves the description entered in the descField.
     *
     * @return the description as a String
     */
    public String getDescription() {
        return descField.getText();
    }

    /**
     * Retrieves the price entered in the priceField.
     *
     * @return the price as a String
     */
    public String getPrice() {
        return priceField.getText();
    }

    /**
     * Retrieves the stock entered in the stockField.
     *
     * @return the stock as a String
     */
    public String getStocks() {
        return stockField.getText();
    }

    /**
     * Retrieves the product ID associated with the update.
     *
     * @return the product ID as an integer
     */
    public int getProductId() {
        return productId;
    }
}
