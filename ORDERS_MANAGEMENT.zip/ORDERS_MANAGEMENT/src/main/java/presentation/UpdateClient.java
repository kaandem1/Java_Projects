package presentation;

import model.Client;

import javax.swing.*;
import java.awt.*;

/**
 * The UpdateClient class represents a GUI window for updating client information.
 * It extends the JFrame class.
 */
public class UpdateClient extends JFrame {
    private JTextField nameField;
    private JTextField addressField;
    private JTextField emailField;
    private JTextField phoneField;
    private JLabel titleLabel;

    private JButton updateButton;
    private int clientId;

    /**
     * Constructs an instance of UpdateClient.
     * Initializes the size, layout, and components of the window.
     *
     * @param client the client to be updated
     */
    public UpdateClient(Client client) {
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        clientId = client.getId();

        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        titleLabel = new JLabel("Updating: " + client.getName() + "'s information");
        this.add(titleLabel, BorderLayout.NORTH);

        formPanel.add(new JLabel("Name:"));
        nameField = new JTextField(client.getName());
        formPanel.add(nameField);

        formPanel.add(new JLabel("Address:"));
        addressField = new JTextField(client.getAddress());
        formPanel.add(addressField);

        formPanel.add(new JLabel("E-mail:"));
        emailField = new JTextField(client.getEmail());
        formPanel.add(emailField);

        formPanel.add(new JLabel("Phone:"));
        phoneField = new JTextField(client.getPhoneNumber());
        formPanel.add(phoneField);

        this.add(formPanel, BorderLayout.CENTER);

        updateButton = new JButton("Update");
        this.add(updateButton, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the updateButton.
     *
     * @return the JButton for updating client information
     */
    public JButton getUpdateButton() {
        return updateButton;
    }

    /**
     * Retrieves the client name entered in the nameField.
     *
     * @return the client name as a String
     */
    public String getClientName() {
        return nameField.getText();
    }

    /**
     * Retrieves the address entered in the addressField.
     *
     * @return the address as a String
     */
    public String getAddress() {
        return addressField.getText();
    }

    /**
     * Retrieves the email entered in the emailField.
     *
     * @return the email as a String
     */
    public String getEmail() {
        return emailField.getText();
    }

    /**
     * Retrieves the phone number entered in the phoneField.
     *
     * @return the phone number as a String
     */
    public String getPhone() {
        return phoneField.getText();
    }

    /**
     * Retrieves the client ID associated with the update.
     *
     * @return the client ID as an integer
     */
    public int getClientId() {
        return clientId;
    }
}