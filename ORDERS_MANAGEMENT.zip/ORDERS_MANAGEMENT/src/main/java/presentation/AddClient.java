package presentation;

import javax.swing.*;

/**
 * The AddClient class represents a JFrame for adding a new client.
 */
public class AddClient extends JFrame {
    private JPanel panel;
    private JTextField nameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField addressField;
    private JButton addButton;

    /**
     * Constructs a new AddClient object.
     */
    public AddClient() {
        this.setSize(300, 300);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        panel = new JPanel();
        this.add(panel);

        // Labels and TextFields
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);
        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);
        JLabel phoneLabel = new JLabel("Phone:");
        phoneField = new JTextField(20);
        JLabel addressLabel = new JLabel("Address:");
        addressField = new JTextField(20);

        // Add button
        addButton = new JButton("Add");

        // Add components to panel
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(phoneLabel);
        panel.add(phoneField);
        panel.add(addressLabel);
        panel.add(addressField);
        panel.add(addButton);

        panel.setVisible(true);
    }

    /**
     * Retrieves the client name entered in the text field.
     *
     * @return The client name.
     */
    public String getClientName() {
        return nameField.getText();
    }

    /**
     * Retrieves the email entered in the text field.
     *
     * @return The email.
     */
    public String getEmail() {
        return emailField.getText();
    }

    /**
     * Retrieves the phone number entered in the text field.
     *
     * @return The phone number.
     */
    public String getPhone() {
        return phoneField.getText();
    }

    /**
     * Retrieves the address entered in the text field.
     *
     * @return The address.
     */
    public String getAddress() {
        return addressField.getText();
    }

    /**
     * Retrieves the add button.
     *
     * @return The add button.
     */
    public JButton getAddButton() {
        return addButton;
    }
}