package presentation;

import model.Product;
import utils.TableUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * The manageProductsPage class represents a GUI window for managing products.
 * It extends the JFrame class.
 */
public class ManageProductsPage extends JFrame{
    private JPanel panel;
    private JTable productsTable;
    private JButton loadProductsButton;
    private JButton addProductButton;
    private JButton editProductButton;
    private JButton deleteProductButton;

    /**
     * Constructs an instance of manageProductsPage.
     * Sets the size and layout of the window.
     * Initializes the components.
     */
    public ManageProductsPage(){
        this.setSize(300, 300);
        this.setLayout(new BorderLayout());

        panel = new JPanel();
        productsTable = new JTable();
        loadProductsButton = new JButton("Load Products");
        addProductButton = new JButton("Add Product");
        editProductButton = new JButton("Edit Product");
        deleteProductButton = new JButton("Delete Product");

        JScrollPane scrollPane = new JScrollPane(productsTable);

        this.add(panel, BorderLayout.CENTER);
        this.add(addProductButton, BorderLayout.NORTH);
        this.add(loadProductsButton, BorderLayout.SOUTH);
        this.add(editProductButton, BorderLayout.WEST);
        this.add(deleteProductButton, BorderLayout.EAST);
        panel.add(scrollPane);
    }

    /**
     * Sets the action listener for the loadProductsButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setLoadProductsButton(ActionListener actionListener) {
        loadProductsButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the deleteProductButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setDeleteProductButton(ActionListener actionListener) {
        deleteProductButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the editProductButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setEditProductButton(ActionListener actionListener) {
        editProductButton.addActionListener(actionListener);
    }

    /**
     * Sets the action listener for the addProductButton.
     *
     * @param actionListener the ActionListener to be set
     */
    public void setAddProductButton(ActionListener actionListener) {
        addProductButton.addActionListener(actionListener);
    }

    /**
     * Loads the provided list of products into the productsTable.
     *
     * @param products the list of products to be loaded
     */
    public void loadProducts(List<Product> products) {
        TableUtil.populateTable(productsTable, products);
    }
}
