package presentation;

import javax.swing.*;

/**
 * The AddProduct class represents a JFrame for adding a new product.
 */
public class AddProduct extends JFrame {

    private JPanel panel;
    private JTextField nameField;
    private JTextField descField;
    private JTextField priceField;
    private JTextField stockField;
    private JButton addButton;

    /**
     * Constructs a new AddProduct object.
     */
    public AddProduct() {
        this.setSize(300, 300);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        panel = new JPanel();
        this.add(panel);

        // Labels and TextFields
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);
        JLabel descLabel = new JLabel("Description:");
        descField = new JTextField(20);
        JLabel priceLabel = new JLabel("Price:");
        priceField = new JTextField(20);
        JLabel stockLabel = new JLabel("Stock:");
        stockField = new JTextField(20);

        // Add button
        addButton = new JButton("Add");

        // Add components to panel
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(descLabel);
        panel.add(descField);
        panel.add(priceLabel);
        panel.add(priceField);
        panel.add(stockLabel);
        panel.add(stockField);
        panel.add(addButton);

        panel.setVisible(true);
    }

    /**
     * Retrieves the product name entered in the text field.
     *
     * @return The product name.
     */
    public String getProductName() {
        return nameField.getText();
    }

    /**
     * Retrieves the description entered in the text field.
     *
     * @return The description.
     */
    public String getDesc() {
        return descField.getText();
    }

    /**
     * Retrieves the price entered in the text field.
     *
     * @return The price.
     */
    public double getPrice() {
        return Double.parseDouble(priceField.getText());
    }

    /**
     * Retrieves the stock quantity entered in the text field.
     *
     * @return The stock quantity.
     */
    public int getStock() {
        return Integer.parseInt(stockField.getText());
    }

    /**
     * Retrieves the add button.
     *
     * @return The add button.
     */
    public JButton getAddButton() {
        return addButton;
    }

}