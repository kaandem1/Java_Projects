package model;

/**
 * The Order class represents an order in the Orders Management system.
 */
public class Order {
    private int id;
    private int cId;
    private int pId;
    private int quantity;

    /**
     * Constructs a new Order object.
     *
     * @param clientId  The ID of the client placing the order.
     * @param productId The ID of the product being ordered.
     * @param quantity  The quantity of the product being ordered.
     */
    public Order(int clientId, int productId, int quantity) {
        this.cId = clientId;
        this.pId = productId;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClientID() {
        return cId;
    }

    public void setClientId(int clientId) {
        this.cId = clientId;
    }

    public int getProductID() {
        return pId;
    }

    public void setProductId(int productId) {
        this.pId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}