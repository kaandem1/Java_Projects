package model;

/**
 * The Client class represents a client in the Orders Management system.
 */
public class Client {

    private int id;
    private String name;
    private String address;
    private String email;
    private String phoneNumber;

    /**
     * Constructs a new Client object.
     *
     * @param name        The name of the client.
     * @param address     The address of the client.
     * @param email       The email address of the client.
     * @param phoneNumber The phone number of the client.
     */
    public Client(String name, String address, String email, String phoneNumber) {
        this.name = name;
        this.address = address;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    /**
     * Constructs a new empty Client object.
     */
    public Client() {

    }

    /**
     * Retrieves the ID of the client.
     *
     * @return The ID of the client.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the ID of the client.
     *
     * @param id The ID to be set.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retrieves the name of the client.
     *
     * @return The name of the client.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the client.
     *
     * @param name The name to be set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Retrieves the address of the client.
     *
     * @return The address of the client.
     */
    public String getAddress() {
        return address;
    }

    public void setAddress(String address){
        this.address = address;
    }
    /**
     * Retrieves the email address of the client.
     *
     * @return The email address of the client.
     */
    public String getEmail() {
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }
    /**
     * Retrieves the phone number of the client.
     *
     * @return The phone number of the client.
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
       this.phoneNumber =phoneNumber ;
    }
}