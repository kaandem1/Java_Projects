package controller;

import businessLayer.ClientBLL;
import businessLayer.OrderBLL;
import businessLayer.ProductBLL;
import model.Client;
import model.Order;
import model.Product;
import presentation.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;


/**
 * The Controller class links the business layer and the presentation layer together.
 * It manages all the operations performed by the user in the MainFrame and all subsequent frames.
 */
public class Controller {
    MainFrame frame = new MainFrame();

    /**
     * Constructs a new Controller object with the provided MainFrame.
     *
     * @param frame The MainFrame for the application.
     */
    public Controller(MainFrame frame){
        this.frame = frame;
        frame.addUseAsAdminButton(new StartListener());
        frame.addUseAsClientButton(new ClientListener());
    }

    /**
     * The StartListener class handles the event when the Use As Admin button is clicked.
     */
    class StartListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            AdminView adminView = new AdminView();
            adminView.addManageClientsButton(new ManageClientsListener());
            adminView.addManageProductsButton(new ManageProductsListener()); // Add this line
            adminView.setVisible(true);
        }

        /**
         * The ManageClientsListener class handles the event when the Manage Clients button is clicked.
         */
        class ManageClientsListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                ManageClientPage manageClientPage = new ManageClientPage();
                ClientBLL clientBLL = new ClientBLL();
                EditClient editClientPage = new EditClient();
                manageClientPage.setDeleteClientButtonActionListener(new DeleteClientListener(clientBLL));

                manageClientPage.setEditClientButtonActionListener(new EditClientListener());

                manageClientPage.setLoadClientsButtonActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        List<Client> clients = clientBLL.findAllClients();
                        manageClientPage.loadClients(clients);
                    }
                });
                manageClientPage.setAddClientButtonActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        AddClient addClientPage = new AddClient();
                        ClientBLL clientBLL = new ClientBLL();
                        addClientPage.getAddButton().addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                String name = addClientPage.getClientName();
                                String email = addClientPage.getEmail();
                                String phone = addClientPage.getPhone();
                                String address = addClientPage.getAddress();
                                Client client = new Client(name, address, email, phone);
                                clientBLL.insertClient(client);
                                JOptionPane.showMessageDialog(addClientPage, "Client added successfully!");
                            }
                        });
                        addClientPage.setVisible(true);
                    }
                });




                manageClientPage.setVisible(true);
            }
        }


        /**
         * The DeleteClientListener class handles the event when the Delete Client button is clicked.
         */
        class DeleteClientListener implements ActionListener {
            private ClientBLL clientBLL;

            public DeleteClientListener(ClientBLL clientBLL) {
                this.clientBLL = clientBLL;
            }
            @Override
            public void actionPerformed(ActionEvent e) {
                String clientIdToDeleteStr = JOptionPane.showInputDialog("Enter client ID to delete:");
                if (clientIdToDeleteStr == null || clientIdToDeleteStr.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Client ID is required.");
                    return;
                }

                try {
                    int clientIdToDelete = Integer.parseInt(clientIdToDeleteStr.trim());
                    Client client = clientBLL.findById(clientIdToDelete);
                    if (client != null) {
                        DeleteClient deleteClientPage = new DeleteClient(client);
                        deleteClientPage.setVisible(true);

                        deleteClientPage.getConfirmDeleteButton().addActionListener(e2 -> {
                            clientBLL.deleteClient(clientIdToDelete);
                            deleteClientPage.dispose();
                            JOptionPane.showMessageDialog(null, "Client has been deleted!");
                        });

                        deleteClientPage.getCancelButton().addActionListener(e2 -> deleteClientPage.dispose());
                    } else {
                        JOptionPane.showMessageDialog(null, "No client with the given ID found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid client ID.");
                }
            }
        }

        /**
         * The DeleteProductListener class handles the event when the Delete Product button is clicked.
         */
        class DeleteProductListener implements ActionListener {
            private ProductBLL productBLL;

            public DeleteProductListener(ProductBLL productBLL) {
                this.productBLL = productBLL;
            }
            @Override
            public void actionPerformed(ActionEvent e) {
                String productIdToDeleteStr = JOptionPane.showInputDialog("Enter product ID to delete:");
                if (productIdToDeleteStr == null || productIdToDeleteStr.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Product ID is required.");
                    return;
                }

                try {
                    int productIdToDelete = Integer.parseInt(productIdToDeleteStr.trim());
                    Product product = productBLL.findById(productIdToDelete);
                    if (product != null) {
                        DeleteProduct deleteProductPage = new DeleteProduct(product);
                        deleteProductPage.setVisible(true);

                        deleteProductPage.getConfirmDeleteButton().addActionListener(e2 -> {
                            productBLL.deleteProduct(productIdToDelete);
                            deleteProductPage.dispose();
                            JOptionPane.showMessageDialog(null, "Product has been deleted!");
                        });

                        deleteProductPage.getCancelButton().addActionListener(e2 -> deleteProductPage.dispose());
                    } else {
                        JOptionPane.showMessageDialog(null, "No Product with the given ID found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Product ID.");
                }
            }
        }

        /**
         * The EditClientListener class handles the event when the Edit Client button is clicked.
         */
        class EditClientListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                EditClient editClientPage = new EditClient();
                ClientBLL clientBLL = new ClientBLL();

                editClientPage.setConfirmButtonActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int id = editClientPage.getClientId();
                        Client client = clientBLL.findById(id);
                        if (client != null) {
                            UpdateClient updateClientPage = new UpdateClient(client);

                            updateClientPage.getUpdateButton().addActionListener(new UpdateClientListener(updateClientPage, clientBLL));

                            updateClientPage.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(editClientPage, "No client found with the given ID!");
                        }
                    }
                });

                editClientPage.setVisible(true);
            }
        }

        /**
         * The EditProductListener class handles the event when the Edit Product button is clicked.
         */
        class EditProductListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                EditProduct editClientPage = new EditProduct();
                ProductBLL productBLL = new ProductBLL();

                editClientPage.setConfirmButtonActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        int id = editClientPage.getClientId();
                        Product product = productBLL.findById(id);
                        if (product != null) {
                            UpdateProduct updateProduct = new UpdateProduct(product);
                            updateProduct.getUpdateButton().addActionListener(new UpdateProductListener(updateProduct, productBLL));

                            updateProduct.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(editClientPage, "No Product found with the given ID!");
                        }
                    }
                });

                editClientPage.setVisible(true);
            }
        }

        /**
         * The ManageProductsListener class handles the event when the Manage Products button is clicked.
         */
        class ManageProductsListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                ManageProductsPage manageProductsPage = new ManageProductsPage();
                ProductBLL productBLL = new ProductBLL();
                EditProduct editProductPage = new EditProduct();
                manageProductsPage.setEditProductButton(new EditProductListener());
                manageProductsPage.setDeleteProductButton(new DeleteProductListener(productBLL));

                manageProductsPage.setLoadProductsButton(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        List<Product> clients = productBLL.findAllProducts();
                        manageProductsPage.loadProducts(clients);
                    }
                });

                manageProductsPage.setAddProductButton(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        AddProduct addProductPage = new AddProduct();
                        ProductBLL productBLL = new ProductBLL();
                        addProductPage.getAddButton().addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                String name = addProductPage.getProductName();
                                String desc = addProductPage.getDesc();
                                Double price = addProductPage.getPrice();
                                Integer stock = addProductPage.getStock();
                                Product product = new Product(name, desc, price, stock);
                                productBLL.insertProduct(product);
                                JOptionPane.showMessageDialog(addProductPage, "Product added successfully!");
                            }
                        });
                        addProductPage.setVisible(true);
                    }
                });
                manageProductsPage.setVisible(true);
            }
        }
    }

    /**
     * The UpdateClientListener class handles the event when the Update button in the Client Update page is clicked.
     */
    class UpdateClientListener implements ActionListener {
        private UpdateClient updateClientPage;
        private ClientBLL clientBLL;

        public UpdateClientListener(UpdateClient updateClientPage, ClientBLL clientBLL) {
            this.updateClientPage = updateClientPage;
            this.clientBLL = clientBLL;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String name = updateClientPage.getClientName();
            String address = updateClientPage.getAddress();
            String email = updateClientPage.getEmail();
            String phone = updateClientPage.getPhone();
            Client updatedClient = new Client(name, address, email, phone);
            updatedClient.setId(updateClientPage.getClientId());
            clientBLL.updateClient(updatedClient);
            JOptionPane.showMessageDialog(updateClientPage, "Client updated successfully!");
        }
    }

    /**
     * The UpdateProductListener class handles the event when the Update button in the Product Update page is clicked.
     */
    class UpdateProductListener implements ActionListener {
        private UpdateProduct updateProductPage;
        private ProductBLL productBLL;

        public UpdateProductListener(UpdateProduct updateProductPage, ProductBLL productBLL) {
            this.updateProductPage = updateProductPage;
            this.productBLL = productBLL;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String name = updateProductPage.getProductName();
            String desc = updateProductPage.getDescription();
            Double price = Double.valueOf(updateProductPage.getPrice());
            Integer stock = Integer.valueOf(updateProductPage.getStocks());
            Product updatedProduct = new Product(name, desc, price, stock);
            updatedProduct.setId(updateProductPage.getProductId());
            productBLL.updateProduct(updatedProduct);
            JOptionPane.showMessageDialog(updateProductPage, "Product updated successfully!");
        }
    }

    /**
     * The ClientListener class handles the event when the Use As Client button is clicked.
     */
    class ClientListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            ClientBLL clientBLL = new ClientBLL();
            ProductBLL productBLL = new ProductBLL();
            OrderBLL orderBLL = new OrderBLL();

            ClientView clientPage = new ClientView();
            clientPage.setConfirmButtonActionListener(e1 -> {
                String email = clientPage.getEmail();
                Client client = clientBLL.findByEmail(email);
                if (client != null) {
                    OrderWindow orderWindow = new OrderWindow(client);


                    List<Product> products = productBLL.findAllProducts();
                    orderWindow.loadProducts(products);


                    orderWindow.setLoadProductsButtonListener(e2 -> {
                        List<Product> updatedProducts = productBLL.findAllProducts();
                        orderWindow.loadProducts(updatedProducts);
                    });

                    orderWindow.setOrderButtonActionListener(e2 -> {
                        int selectedProductId = orderWindow.getSelectedProductId();
                        int quantity = orderWindow.getQuantity();

                        Product product = productBLL.findById(selectedProductId);
                        if (product != null) {
                            if (product.getStock() < quantity) {
                                JOptionPane.showMessageDialog(null, "Insufficient stock for this product.");
                                return;
                            }
                            productBLL.updateProduct(product);

                            Order order = new Order(client.getId(), selectedProductId, quantity);
                            orderBLL.insertOrder(order);

                            JOptionPane.showMessageDialog(null, "Order placed successfully!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Invalid product selected.");
                        }
                    });

                    orderWindow.setVisible(true);
                    clientPage.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "No client with the given email found.");
                }
            });

            clientPage.setVisible(true);
        }
    }

    /**
     * The entry point for the program.
     */
    public static void main( String[] args )
    {
        MainFrame frame1 = new MainFrame();
        frame1.setVisible(true);
        frame1.setSize(400,400);
        Controller controller = new Controller(frame1);
    }
}
