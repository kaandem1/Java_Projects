package businessLayer;

import dataAccess.OrderDAO;
import model.Client;
import model.Order;
import model.Product;

import java.util.List;
import java.util.NoSuchElementException;

/**
 * The OrderBLL class represents the business logic layer for managing orders.
 * It contains methods for retrieving, inserting, and deleting orders.
 */
public class OrderBLL {

    private OrderDAO orderDAO;
    private ClientBLL clientBLL;
    private ProductBLL productBLL;

    /**
     * Constructs a new OrderBLL object.
     * Initializes the OrderDAO, ClientBLL, and ProductBLL.
     */
    public OrderBLL() {
        orderDAO = new OrderDAO();
        clientBLL = new ClientBLL();
        productBLL = new ProductBLL();
    }

    /**
     * Retrieves all orders.
     *
     * @return A list of all orders.
     * @throws NoSuchElementException if no orders are found.
     */
    public List<Order> findAllOrders() {
        List<Order> orders = orderDAO.getAllOrders();
        if (orders == null || orders.isEmpty()) {
            throw new NoSuchElementException("No orders found!");
        }
        return orders;
    }

    /**
     * Finds an order by ID.
     *
     * @param id The ID of the order to find.
     * @return The order with the given ID.
     * @throws NoSuchElementException if no order is found with the given ID.
     */
    public Order findById(int id) {
        Order order = orderDAO.findById(id);
        if (order == null) {
            throw new NoSuchElementException("No order with the given ID!");
        }
        return order;
    }

    /**
     * Inserts a new order.
     *
     * @param order The order to be inserted.
     * @throws NoSuchElementException if the client or product is not found.
     * @throws IllegalArgumentException if there is not enough stock for the product.
     */
    public void insertOrder(Order order) {
        Client client = clientBLL.findById(order.getClientID());
        Product product = productBLL.findById(order.getProductID());

        if (client == null || product == null) {
            throw new NoSuchElementException("Client or Product not found!");
        }

        if (product.getStock() < order.getQuantity()) {
            throw new IllegalArgumentException("Not enough stock!");
        }

        product.setStock(product.getStock() - order.getQuantity());
        productBLL.updateProduct(product);

        orderDAO.addOrder(order);
    }

    /**
     * Deletes an order by ID.
     *
     * @param id The ID of the order to be deleted.
     */
    public void deleteOrder(int id) {
        orderDAO.deleteOrder(id);
    }
}
