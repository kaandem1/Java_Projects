package businessLayer;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import businessLayer.validators.*;
import dataAccess.ProductDAO;
import model.Product;


/**
 * The ProductBLL class represents the business logic layer for managing products.
 * It contains methods for retrieving, inserting, updating, and deleting products.
 */
public class ProductBLL {

    private List<Validator<Product>> validators;
    private ProductDAO productDAO;

    /**
     * Constructs a new ProductBLL object.
     * Initializes the list of validators and the ProductDAO.
     */
    public ProductBLL() {
        validators = new ArrayList<Validator<Product>>();
        validators.add(new StockValidator());
        //validators.add(new ProductNameValidator());

        productDAO = new ProductDAO();
    }

    /**
     * Retrieves all products.
     *
     * @return A list of all products.
     * @throws NoSuchElementException if no products are found.
     */
    public List<Product> findAllProducts() {
        List<Product> products = productDAO.getAllProducts();
        if (products == null || products.isEmpty()) {
            throw new NoSuchElementException("No products found!");
        }
        return products;
    }

    /**
     * Inserts a new product.
     *
     * @param product The product to be inserted.
     */
    public void insertProduct(Product product) {
        for (Validator<Product> v : validators) {
            v.validate(product);
        }
        productDAO.addProduct(product);
    }

    /**
     * Updates a product.
     *
     * @param product The product to be updated.
     */
    public void updateProduct(Product product) {
        for (Validator<Product> v : validators) {
            v.validate(product);
        }
        productDAO.updateProduct(product);
    }

    /**
     * Deletes a product by ID.
     *
     * @param id The ID of the product to be deleted.
     */
    public void deleteProduct(int id) {
        productDAO.deleteProduct(id);
    }

    /**
     * Finds a product by ID.
     *
     * @param id The ID of the product to find.
     * @return The product with the given ID.
     * @throws NoSuchElementException if no product is found with the given ID.
     */
    public Product findById(int id) {
        Product product = productDAO.findById(id);
        if (product == null) {
            throw new NoSuchElementException("No product with the given ID!");
        }
        return product;
    }
}