package businessLayer;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import businessLayer.validators.EmailValidator;
import businessLayer.validators.PhoneValidator;
import businessLayer.validators.AddressValidator;
import businessLayer.validators.Validator;
import dataAccess.ClientDAO;
import model.Client;

/**
 * The ClientBLL class represents the business logic layer for managing clients.
 * It contains methods for retrieving, updating, inserting, and deleting clients.
 */
public class ClientBLL {

    private List<Validator<Client>> validators;
    private ClientDAO clientDAO;

    /**
     * Constructs a new ClientBLL object.
     * Initializes the list of validators and the ClientDAO.
     */
    public ClientBLL() {
        validators = new ArrayList<Validator<Client>>();
        validators.add(new EmailValidator());
        validators.add(new AddressValidator());
        validators.add(new PhoneValidator());

        clientDAO = new ClientDAO();
    }

    /**
     * Retrieves all clients.
     *
     * @return A list of all clients.
     * @throws NoSuchElementException if no clients are found.
     */
    public List<Client> findAllClients() {
        List<Client> clients = clientDAO.getAllClients();
        if (clients == null || clients.isEmpty()) {
            throw new NoSuchElementException("No clients");
        }
        return clients;
    }

    /**
     * Finds a client by ID.
     *
     * @param id The ID of the client to find.
     * @return The client with the given ID.
     * @throws NoSuchElementException if no client is found with the given ID.
     */
    public Client findById(int id) {
        Client client = clientDAO.findById(id);
        if (client == null) {
            throw new NoSuchElementException("No client with the given ID!");
        }
        return client;
    }

    /**
     * Finds a client by email.
     *
     * @param email The email address of the client to find.
     * @return The client with the given email address.
     * @throws NoSuchElementException if no client is found with the given email address.
     */
    public Client findByEmail(String email) {
        Client client = clientDAO.findByEmail(email);
        if (client == null) {
            throw new NoSuchElementException("No client with the given E-mail address!");
        }
        return client;
    }

    /**
     * Updates a client.
     *
     * @param client The client to be updated.
     */
    public void updateClient(Client client) {
        for (Validator<Client> v : validators) {
            v.validate(client);
        }
        clientDAO.updateClient(client);
    }

    /**
     * Inserts a new client.
     *
     * @param client The client to be inserted.
     */
    public void insertClient(Client client) {
        for (Validator<Client> v : validators) {
            v.validate(client);
        }
        clientDAO.addClient(client);
    }

    /**
     * Deletes a client by ID.
     *
     * @param id The ID of the client to be deleted.
     */
    public void deleteClient(int id) {
        clientDAO.deleteClient(id);
    }
}