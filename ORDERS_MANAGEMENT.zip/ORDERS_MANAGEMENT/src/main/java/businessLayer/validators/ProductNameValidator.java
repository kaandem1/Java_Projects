package businessLayer.validators;

import dataAccess.ProductDAO;
import model.Product;

public class ProductNameValidator implements Validator<Product> {
    private ProductDAO productDAO;

    /**
     * Constructs a new ProductNameValidator object and initializes the associated ProductDAO.
     */
    public ProductNameValidator() {
        this.productDAO = new ProductDAO();
    }

    /**
     * Validates the given Product object.
     * It checks if a product with the same name already exists in the database.
     *
     * @param product The Product object to be validated.
     * @throws IllegalArgumentException If a product with the same name already exists in the database.
     */
    public void validate(Product product) {
        Product existingProduct = productDAO.findByName(product.getName());
        if (existingProduct != null) {
            throw new IllegalArgumentException("Product with this name already exists!");
        }
    }
}
