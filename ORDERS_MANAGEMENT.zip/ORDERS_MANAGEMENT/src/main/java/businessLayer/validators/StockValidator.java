package businessLayer.validators;

import java.util.regex.Pattern;
import model.Product;

/**
 * The StockValidator class is responsible for validating the stock value of a product.
 * It implements the Validator interface with the Product type.
 */
public class StockValidator implements Validator<Product> {

    private static final String STOCK_PATTERN = "^[1-9]\\d*$";

    /**
     * Validates the stock value of the product.
     *
     * @param product The product whose stock value needs to be validated.
     * @throws IllegalArgumentException if the stock value is invalid.
     */
    public void validate(Product product) {
        Pattern pattern = Pattern.compile(STOCK_PATTERN);
        if (!pattern.matcher(String.valueOf(product.getStock())).matches()) {
            throw new IllegalArgumentException("Invalid stock value!");
        }
    }
}