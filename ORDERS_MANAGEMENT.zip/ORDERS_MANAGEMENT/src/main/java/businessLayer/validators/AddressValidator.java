

package businessLayer.validators;

import java.util.regex.Pattern;
import model.Client;

/**
 * The AddressValidator class is responsible for validating the address of a client.
 * It implements the Validator interface with the Client type.
 */
public class AddressValidator implements Validator<Client> {

    private static final String ADDRESS_PATTERN = "^[a-zA-ZăîâșțĂÎÂȘȚ0-9\\s,'-]*$";

    /**
     * Validates the address of the client.
     *
     * @param client The client whose address needs to be validated.
     * @throws IllegalArgumentException if the address is invalid.
     */
    public void validate(Client client) {
        Pattern pattern = Pattern.compile(ADDRESS_PATTERN);
        if (!pattern.matcher(client.getAddress()).matches()) {
            throw new IllegalArgumentException("Invalid address!");
        }
    }
}
