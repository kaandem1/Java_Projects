package businessLayer.validators;

import java.util.regex.Pattern;
import model.Client;

/**

 The PhoneValidator class is responsible for validating the phone number of a client.

 It implements the Validator interface with the Client type.
 */
public class PhoneValidator implements Validator<Client> {

    private static final String PHONE_PATTERN = "^(02|03|07|0266)\\d{8}$";

    /**

     Validates the phone number of the client.
     @param client The client whose phone number needs to be validated.
     @throws IllegalArgumentException if the phone number is invalid.
     */
    public void validate(Client client) {
        Pattern pattern = Pattern.compile(PHONE_PATTERN);
        if (!pattern.matcher(client.getPhoneNumber()).matches()) {
            throw new IllegalArgumentException("Invalid phone number!");
        }
    }
}