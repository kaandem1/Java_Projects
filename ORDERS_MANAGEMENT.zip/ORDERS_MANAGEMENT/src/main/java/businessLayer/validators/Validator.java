package businessLayer.validators;

/**
 * The Validator interface represents a generic validator.
 *
 * @param <T> The type of object to be validated.
 */
public interface Validator<T> {

    /**
     * Validates the specified object.
     *
     * @param t The object to be validated.
     */
    public void validate(T t);
}