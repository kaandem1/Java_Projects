package dataAccess;

import model.Client;
import model.Product;

import java.util.List;

/**
 * The ProductDAO class provides data access methods for the Product model.
 * It extends the AbstractDAO class.
 */
public class ProductDAO extends AbstractDAO<Product> {

    /**
     * Adds a new product to the database.
     *
     * @param product The product to be added.
     */
    public void addProduct(Product product) {
        this.insert(product);
    }

    /**
     * Updates a product in the database.
     *
     * @param product The product to be updated.
     */
    public void updateProduct(Product product) {
        this.update(product);
    }

    /**
     * Deletes a product from the database by ID.
     *
     * @param id The ID of the product to be deleted.
     */
    public void deleteProduct(int id) {
        this.delete(id);
    }

    /**
     * Finds a product by ID.
     *
     * @param id The ID of the product to find.
     * @return The product with the given ID, or null if not found.
     */
    public Product findById(int id) {
        return super.findById(id);
    }

    /**
     * Retrieves all products from the database.
     *
     * @return A list of all products.
     */
    public List<Product> getAllProducts() {
        return this.findAll();
    }
}