package dataAccess;

import model.Client;

import java.util.*;

/**
 * The ClientDAO class provides data access methods for the Client model.
 * It extends the AbstractDAO class.
 */
public class ClientDAO extends AbstractDAO<Client> {

    /**
     * Adds a new client to the database.
     *
     * @param client The client to be added.
     */
    public void addClient(Client client) {
        this.insert(client);
    }

    /**
     * Finds a client by ID.
     *
     * @param id The ID of the client to find.
     * @return The client with the given ID, or null if not found.
     */
    public Client findById(int id) {
        return super.findById(id);
    }

    /**
     * Finds a client by email.
     *
     * @param email The email address of the client to find.
     * @return The client with the given email address, or null if not found.
     */
    public Client findByEmail(String email) {
        return super.findByEmail(email);
    }

    /**
     * Updates a client in the database.
     *
     * @param client The client to be updated.
     */
    public void updateClient(Client client) {
        this.update(client);
    }

    /**
     * Deletes a client from the database by ID.
     *
     * @param id The ID of the client to be deleted.
     */
    public void deleteClient(int id) {
        this.delete(id);
    }

    /**
     * Retrieves all clients from the database.
     *
     * @return A list of all clients.
     */
    public List<Client> getAllClients() {
        return this.findAll();
    }
}