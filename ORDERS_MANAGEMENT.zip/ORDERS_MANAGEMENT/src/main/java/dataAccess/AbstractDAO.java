package dataAccess;

import connection.ConnectionFactory;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This is a Generic Abstract Data Access Object (DAO) class used for performing database operations.
 * The operations include Create, Retrieve, Update, and Delete (CRUD) for any type of objects (entities/models).
 *
 * @param <T> This is a type parameter which represents the Type of Object (entity/model).
 */
public class AbstractDAO<T>{
    protected static final Logger LOGGER=   Logger.getLogger(AbstractDAO.class.getName());
    private final Class<T> type;
    /**
     * The default constructor of the AbstractDAO class.
     * It sets the 'type' class variable with the actual type argument of the extending class.
     */
    public AbstractDAO(){
        this.type =(Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];

    }

    /**
     * Creates an SQL insert query string dynamically using reflection.
     * The insert query string is specific to the type of object.
     *
     * @return The SQL insert query string.
     */
    private String createInsertQuery() {
        StringBuilder fields = new StringBuilder();
        StringBuilder values = new StringBuilder();

        for (Field field : type.getDeclaredFields()) {
            if (!field.getName().equalsIgnoreCase("id")) {
                fields.append(field.getName()).append(",");
                values.append("?").append(",");
            }
        }
        fields.setLength(fields.length() - 1);
        values.setLength(values.length() - 1);

        String tableName = type.getSimpleName().toLowerCase() + "s";
        return "INSERT INTO " + tableName + " (" + fields.toString() + ") VALUES (" + values.toString() + ")";
    }

    /**
     * Creates an SQL update query string dynamically using reflection.
     * The update query string is specific to the type of object.
     *
     * @return The SQL update query string.
     */
    private String createUpdateQuery() {
        StringBuilder query = new StringBuilder();
        String tableName = getTableName(type);
        query.append("UPDATE ").append(tableName).append(" SET ");

        for (Field field : type.getDeclaredFields()) {
            if (!field.getName().equalsIgnoreCase("id")) {
                query.append(field.getName()).append(" = ?, ");
            }
        }

        // Remove trailing comma and space
        query.setLength(query.length() - 2);

        query.append(" WHERE id = ?");

        return query.toString();
    }

    /**
     * Retrieves all records of a specific type of object from the database.
     *
     * @return List of objects of type T.
     */
    public List<T> findAll() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String tableName = getTableName(type);
        String query = "SELECT * FROM " + tableName;
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();
            return createObjects(resultSet);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findAll " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Retrieves an object of a specific type from the database by its ID.
     *
     * @param id The ID of the object.
     * @return The object of type T with the specified ID.
     */
    public T findById(int id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String tableName = getTableName(type);
        String query = "SELECT * FROM " + tableName + " WHERE id = ?";
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();
            List<T> results = createObjects(resultSet);
            if (results.isEmpty()) {
                return null; // or throw an exception
            } else {
                return results.get(0);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findById " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Retrieves an object of a specific type from the database by its email.
     *
     * @param email The email of the object.
     * @return The object of type T with the specified email.
     */
    public T findByEmail(String email) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String tableName = getTableName(type);
        String query = "SELECT * FROM " + tableName + " WHERE email = ?";
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            statement.setString(1, email);
            resultSet = statement.executeQuery();
            List<T> results = createObjects(resultSet);
            if (results.isEmpty()) {
                return null;
            } else {
                return results.get(0);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findByEmail " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Retrieves an object of a specific type from the database by its name.
     *
     * @param name The name of the object.
     * @return The object of type T with the specified name.
     */
    public T findByName(String name) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String tableName = getTableName(type);
        String query = "SELECT * FROM " + tableName + " WHERE name = ?";
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            statement.setString(1, name);
            resultSet = statement.executeQuery();
            List<T> results = createObjects(resultSet);
            if (results.isEmpty()) {
                return null;
            } else {
                return results.get(0);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findByName " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * A helper method to map the type of object to its corresponding database table name.
     *
     * @param type The Class of the object type.
     * @return The table name in the database corresponding to the object type.
     */
    private String getTableName(Class<T> type) {
        String simpleName = type.getSimpleName();
        switch (simpleName) {
            case "Client":
                return "clients";
            case "Product":
                return "products";
            // Add more cases as needed
            default:
                return simpleName;
        }
    }

    /**
     * Creates and returns a list of objects of a specific type from the ResultSet.
     *
     * @param resultSet The ResultSet object from a database query.
     * @return A list of objects constructed from the ResultSet.
     */
    private List<T> createObjects(ResultSet resultSet) {
        List<T> list = new ArrayList<T>();
        Constructor[] ctors = type.getDeclaredConstructors();
        Constructor ctor = null;
        for (int i = 0; i < ctors.length; i++) {
            ctor = ctors[i];
            if (ctor.getGenericParameterTypes().length == 0)
                break;
        }
        try {
            while (resultSet.next()) {
                ctor.setAccessible(true);
                T instance = (T)ctor.newInstance();
                for (Field field : type.getDeclaredFields()) {
                    String fieldName = field.getName();
                    Object value = resultSet.getObject(fieldName);
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fieldName, type);
                    Method method = propertyDescriptor.getWriteMethod();
                    method.invoke(instance, value);
                }
                list.add(instance);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IntrospectionException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Inserts a new record (object of type T) into the database.
     *
     * @param t The object to be inserted.
     * @return The inserted object, updated with the generated database ID.
     */
    public T insert(T t) {
        Connection connection = null;
        PreparedStatement statement = null;
        String query = createInsertQuery();
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            int index = 1;
            for (Field field : type.getDeclaredFields()) {
                if (!field.getName().equalsIgnoreCase("id")) {
                    field.setAccessible(true);
                    statement.setObject(index, field.get(t));
                    index++;
                }
            }
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                Field field = type.getDeclaredField("id");
                field.setAccessible(true);
                field.set(t, generatedKeys.getInt(1));
            }
        } catch (SQLException | IllegalAccessException | NoSuchFieldException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:insert " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return t;
    }

    /**
     * Updates an existing record in the database.
     *
     * @param t The object containing the updated data.
     * @return The object that was updated.
     */
    public T update(T t) {
        Connection connection = null;
        PreparedStatement statement = null;
        String query = createUpdateQuery();
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            int index = 1;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                if (!field.getName().equalsIgnoreCase("id")) {
                    statement.setObject(index, field.get(t));
                    index++;
                }
            }
            Field field = type.getDeclaredField("id");
            field.setAccessible(true);
            statement.setObject(index, field.get(t));

            statement.executeUpdate();
        } catch (SQLException | IllegalAccessException | NoSuchFieldException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:update " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return t;
    }

    /**
     * Deletes a record from the database by its ID.
     *
     * @param id The ID of the record to be deleted.
     */
    public void delete(int id) {
        Connection connection = null;
        PreparedStatement statement = null;
        String tableName = getTableName(type);
        String query = "DELETE FROM " + tableName + " WHERE id = ?";
        try {
            connection = ConnectionFactory.getTheConnection();
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:delete " + e.getMessage());
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
    }



}

