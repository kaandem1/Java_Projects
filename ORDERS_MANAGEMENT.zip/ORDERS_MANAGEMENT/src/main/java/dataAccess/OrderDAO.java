package dataAccess;
import model.Order;

import java.util.*;

/**
 * The OrderDAO class provides data access methods for the Order model.
 * It extends the AbstractDAO class.
 */
public class OrderDAO extends AbstractDAO<Order> {

    /**
     * Adds a new order to the database.
     *
     * @param order The order to be added.
     */
    public void addOrder(Order order) {
        this.insert(order);
    }

    /**
     * Finds an order by ID.
     *
     * @param id The ID of the order to find.
     * @return The order with the given ID, or null if not found.
     */
    public Order findById(int id) {
        return super.findById(id);
    }

    /**
     * Retrieves all orders from the database.
     *
     * @return A list of all orders.
     */
    public List<Order> getAllOrders() {
        return this.findAll();
    }

    /**
     * Deletes an order from the database by ID.
     *
     * @param id The ID of the order to be deleted.
     */
    public void deleteOrder(int id) {
        this.delete(id);
    }
}