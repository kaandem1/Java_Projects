package utils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

/**
 * The TableUtil class provides utility methods for populating a JTable with data.
 */
public class TableUtil {
    /**
     * Populates the provided JTable with the data from the given list of items.
     *
     * @param table the JTable to be populated
     * @param items the list of items to be displayed in the table
     * @param <T>   the type of the items
     */
    public static <T> void populateTable(JTable table, List<T> items) {
        if (items.isEmpty()) {
            return;
        }
        T firstItem = items.get(0);
        Field[] fields = firstItem.getClass().getDeclaredFields();

        String[] columns = Arrays.stream(fields)
                .map(Field::getName)
                .toArray(String[]::new);

        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);

        for (T item : items) {
            Object[] row = new Object[columns.length];
            for (int i = 0; i < fields.length; i++) {
                try {
                    fields[i].setAccessible(true);
                    row[i] = fields[i].get(item);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            tableModel.addRow(row);
        }

        table.setModel(tableModel);
    }
}